package com.neimas.tasklocation;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;


public class MainActivity extends AppCompatActivity {
    private Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        //The device cannot rotate
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        setContentView(R.layout.activity_main);
        intent = new Intent(MainActivity.this, FirstActivity.class);
        splash(3000);
    }
   //to make the screen wait 3 seconds and go to "firstActivity"
    public void splash (final int x) {
        new Thread(new Runnable() {
            public void run() {
                try {
                    Thread.sleep(x);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                startActivity(intent);
                finish();
            }
//              Log.d("mylog", "thread0 finush");
        }).start();
    }



    @Override
    protected void onStart()
    {
        super.onStart();
    }

    @Override
    protected void onStop()
    {
        super.onStop();
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

}



