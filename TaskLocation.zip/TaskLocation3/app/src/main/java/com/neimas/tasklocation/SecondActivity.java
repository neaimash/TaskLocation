package com.neimas.tasklocation;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class SecondActivity extends AppCompatActivity {
    private int update=0;
    private String task=" ";
    private SQLiteDatabase todoDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        setContentView(R.layout.activity_second);
        //get the name of the task you clicked on
        Intent intent1= getIntent();
        task = intent1.getStringExtra("task");

        openDB();
        //Loading the task details from the database
        loadDetails();
        //Loading the task locations from the database
        loadLocation();
        //click on "add detail"
        Button btn = findViewById(R.id.btn_detail_ID);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText myEditText =  (EditText) findViewById(R.id.edt_details_ID);
                String text = myEditText.getText().toString();
                if (text.matches("")) {
                    Toast.makeText(getApplicationContext(), "You did not enter a new detail", Toast.LENGTH_SHORT).show();
                    return;
                }
                TextView myText = findViewById(R.id.text_details_id);
                myText.append("\n#");
                myText.append(text);
                myEditText.getText().clear();
                updateDetail();
            }
        });
        //click on "choose location"
        Button btn2 = findViewById(R.id.btn_location_ID);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView myText = findViewById(R.id.text_details_id);
                String detail=myText.getText().toString();
                Intent intent2 = new Intent(SecondActivity.this, ThirdActivity.class);
                intent2.putExtra("task", task);
                intent2.putExtra("detail", detail);
                intent2.putExtra("update",update);
                startActivity(intent2);
            }
        });
       //click on "delete details"
        Button btn3 = findViewById(R.id.btn_delete_ID);
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView myText =  (TextView) findViewById(R.id.text_details_id);
                if(myText.getText().toString().isEmpty()){
                    Toast.makeText(getApplicationContext(), "there is no details to delete...", Toast.LENGTH_SHORT).show();
                    return;
                }
                myText.setText("");
                updateDetail();
            }
        });
       //clock on "back"
        Button btn4 = findViewById(R.id.back_id);
        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(update!=1){
                    Toast.makeText(getApplicationContext(), "You must choose location to the task", Toast.LENGTH_SHORT).show();
                    return;
                }
                Intent intent = new Intent(SecondActivity.this, FirstActivity.class);
                startActivity(intent);
            }
        });
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
    }


    private void loadDetails() {
       TextView myText = (TextView) findViewById(R.id.text_details_id);
       new Thread(new Runnable() {
       @Override
       public void run() {
        try {
            // from db
            String sql1 = "SELECT detail FROM todosTable WHERE task='" + task + "'";
            Cursor cur1 = todoDB.rawQuery(sql1, null);
            int column1 = cur1.getColumnIndex("detail");
            if (cur1.moveToFirst() && cur1 != null) {
                String value = cur1.getString(column1);
                //UI component in the main thread
                runOnUiThread(new Runnable() {
                 public void run() {
                  myText.setText(value);
                 }
                });
            }
            Log.d("mylog", "thread2 finush");
        } catch (Exception e) {
        }
       }
       }).start();
    }

        private void loadLocation() {
            TextView locn = findViewById(R.id.text_loc_id);
           new Thread(new Runnable() {
           @Override
            public void run() {
               try {
                 String sql2 = "SELECT location FROM todosTable WHERE task='" + task + "'";
                 Cursor cur2 = todoDB.rawQuery(sql2, null);
                  int Column2 = cur2.getColumnIndex("location");
                  if (cur2.moveToFirst() && cur2 != null) {
                     // Get the results and store them in a String
                     String location = cur2.getString(Column2);
                     //UI component in the main thread
                      runOnUiThread(new Runnable() {
                      public void run() {
                         locn.setText( "\n" + location);
                      }
                      });
                  if(location!=null)
                     update=1;
                   }
                } catch (Exception e) {
                }
               Log.d("mylog", "thread3 finush");
            }
            }).start();
        }

    //update details of exiting task
    private void updateDetail(){
        TextView myText = findViewById(R.id.text_details_id);
        String myDetail=myText.getText().toString();
        TextView txt = findViewById(R.id.text_loc_id);
        String myLoc=txt.getText().toString();
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String sql1 = "UPDATE todostable SET detail='" + myDetail + "' , location='" + myLoc + "' WHERE task='" + task + "'";
                    try {
                        todoDB.execSQL(sql1);
                    } catch (Exception e) {
                    }
                    Log.d("mylog", "thread4 finush");
                } catch (Exception e) {
                }
            }
        }).start();
    }

    public void openDB() {
        try {
            todoDB = openOrCreateDatabase("todoDB", MODE_PRIVATE, null);
            // build an SQL statement to create 'contacts' table (if not exists)
            String sql = "CREATE TABLE IF NOT EXISTS todosTable (id integer primary key, task VARCHAR,detail VARCHAR,location VARCHAR);";
            todoDB.execSQL(sql);
        }
        catch (Exception e) {
            Log.d("debug", "Error Creating Database");
        }
    }
}











