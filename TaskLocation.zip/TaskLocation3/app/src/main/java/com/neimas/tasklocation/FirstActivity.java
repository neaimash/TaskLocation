package com.neimas.tasklocation;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class FirstActivity extends AppCompatActivity {
    private ArrayList<String> data;
    private ArrayAdapter<String> adapter;
    private ListView listView;
    AlertDialog.Builder builder;
    private SQLiteDatabase todoDB;
    private  String todo;
    private MyReceiver myReceiver;
    private IntentFilter filter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        setContentView(R.layout.activity_first);

        //Access permission check
        isPermissionToReadGPSLocationOK();
        //function for BroadcastReceiver when change timezone
        setupBroadcastReceiver();
        //in the install it is create dataase and after it is open
        openDB();
        //load tasks from the DB
        data = loadData();
        // 2. create adapter
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, data);
        // 3. setup ListView
        listView = findViewById(R.id.listViewID);
        listView.setAdapter(adapter);

        // calling this activity's function to
        // use ActionBar utility methods
        ActionBar actionBar = getSupportActionBar();
        // providing title for the ActionBar
        actionBar.setTitle("  TaskLocatin | Action Bar");
        // methods to display the icon in the ActionBar
        actionBar.setDisplayUseLogoEnabled(true);
        actionBar.setDisplayShowHomeEnabled(true);

       //click on item in the list go to "secondActivity"
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                todo = data.get(position);
                Intent intent = new Intent(FirstActivity.this, SecondActivity.class);
                if (todo != null) {
                    intent.putExtra("task", todo);
                }
                startActivity(intent);
            }
        });
        //delete item from the list by long click
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                todo=data.get(position);

                new Thread(new Runnable() {
                @Override
                public void run() {
                  try {
                      try {
                          String sql="DELETE from todosTable WHERE task='"+todo+"'";//delete the task from DB
                          todoDB.execSQL(sql);
                          Log.d("mylog", "thread1 finish");
                      }
                      catch (Exception e) {
                      }
                  } catch (Exception e) {
                  }
                }
                }).start();
                data.remove(position);
                adapter.notifyDataSetChanged();  // refresh listview with the new data
                return true;
            }
        });
        //click on "add task" button
        Button btn = findViewById(R.id.btnAddID);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText edt = findViewById(R.id.edtID);
                String myEdit = edt.getText().toString();
                if (myEdit.equals("")) {
                    Toast.makeText(getApplicationContext(), "You did not enter a task", Toast.LENGTH_SHORT).show();
                    return;
                }
                data.add(myEdit);
                adapter.notifyDataSetChanged();  // refresh listview with the new data
                //Redirects edit text to new input
                edt.getText().clear();
            }
        });
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Cancellation of shelter registration
        unregisterReceiver(myReceiver);
    }


    private ArrayList<String> loadData() {
        ArrayList<String> datalist = new ArrayList<>();
        // from db
        // A Cursor provides read and write access to database results
          new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String sql = "SELECT task FROM todosTable";
                    Cursor cursor = todoDB.rawQuery(sql, null);
                    // Get the index for the column name provided
                    int todoColumn = cursor.getColumnIndex("task");
                    // Move to the first row of results & Verify that we have results
                    if (cursor != null && cursor.moveToFirst()) {
                        do {
                            // Get the results and store them in a String
                            String myTodo = cursor.getString(todoColumn);
                            datalist.add(myTodo);
                            // Keep getting results as long as they exist
                        } while (cursor.moveToNext());
                    }

                } catch (Exception e)
                {
                }
            }
        }).start();
        return datalist;
    }

    public void openDB() {
        try {
            todoDB = openOrCreateDatabase("todoDB", MODE_PRIVATE, null);
            // build an SQL statement to create 'contacts' table (if not exists)
            String sql = "CREATE TABLE IF NOT EXISTS todosTable (id integer primary key, task VARCHAR,detail VARCHAR,location VARCHAR);";
            todoDB.execSQL(sql);
        }
        catch (Exception e) {
            Log.d("debug", "Error Creating Database");
        }
    }

    // method to inflate the options menu when
    // the user opens the menu for the first time
    @Override
    public boolean onCreateOptionsMenu( Menu menu ) {
        getMenuInflater().inflate(R.menu.main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    // methods to control the operations that will
    // happen when user clicks on the action buttons
    @Override
    public boolean onOptionsItemSelected( @NonNull MenuItem item ) {

        switch (item.getItemId()){
            case R.id.about:
                aboutDialog();
                break;
            case R.id.settings:
                Intent intent = new Intent(FirstActivity.this, SettingsActivity.class);
                startActivity(intent);
                break;
            case R.id.exit:
                exitDialog();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private void exitDialog(){
        builder = new AlertDialog.Builder(this);
        //Setting message manually and performing action on button click
        builder.setMessage("Do you want to close this application?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        finishAffinity();
                        System.exit(0);
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        //  Action for 'NO' Button
                        dialog.cancel();
                    }
                });
        //Creating dialog box
        AlertDialog alert = builder.create();
        //Setting the title manually
        alert.setTitle("TaskLocation");
        alert.show();
    }

    private void aboutDialog(){
        builder = new AlertDialog.Builder(this);
        //Setting message manually and performing action on button click
        builder.setMessage("application name:  TaskLoc"+"\n"+"student name:  Neima Shraga"+"\n"+"Date of Submission  :18.07.22"+"Operating System   :pixel 3, API 30 , Android 11.(R)")
                .setCancelable(false)
                .setNegativeButton("close", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        //  Action for 'close' Button
                        dialog.cancel();
                    }
                });
        //Creating dialog box
        AlertDialog alert = builder.create();
        //Setting the title manually
        alert.setTitle("About the application");
        alert.show();
    }

    private void setupBroadcastReceiver() {
        myReceiver = new MyReceiver();
        filter = new IntentFilter(Intent.ACTION_TIMEZONE_CHANGED);
        // Registration of a transmission receiver for a change in the battery
        registerReceiver(myReceiver, filter);
    }


    private boolean isPermissionToReadGPSLocationOK() {
        LocationManager locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

        // first, check if GPS Provider (Location) is Enabled ?
        if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            // second, check if permission to ACCESS_FINE_LOCATION is granted ?
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED )
                return true;
            else {
                Toast.makeText(getApplicationContext(), "NO Permission To Access Location!", Toast.LENGTH_SHORT).show();
                // Show to user requestPermissions Dialog
                ActivityCompat.requestPermissions(FirstActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 111);
                return false;
            }
        }
        else {
            return false;
        }
    }
}


















































