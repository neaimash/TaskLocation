package com.neimas.tasklocation;

import android.annotation.SuppressLint;
import android.app.Service;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.IBinder;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.util.Log;

import androidx.core.app.NotificationCompat;

import java.util.List;

public class MyService extends Service {
    private boolean isRunning;
    public static final String CHANNEL_ID = "FGServiceChannel";
    public static final int FG_NOTIFICATION_ID = 111;
    private LocationListener locationListener;
    private LocationManager locationManager;
    private String curentAddress;
    private String myTask;
    private SQLiteDatabase todoDB;
    private PendingIntent pendingIntent;
    private int flag=0;
    int countMyTask=0;
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // create Notification Channel
        NotificationChannel serviceChannel = new NotificationChannel(
                CHANNEL_ID,
                "FG Service Channel",
                NotificationManager.IMPORTANCE_HIGH
        );
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        manager.createNotificationChannel(serviceChannel);
        // start the MainActivity when notification tap
        Intent notificationIntent = new Intent(this, MainActivity.class);
         pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, 0);
        //create fourgrand notification
        createFGNotification();
        openDB();
        DeviceLocation();
        isRunning = true;
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        locationManager.removeUpdates(locationListener);
        isRunning = false;
    }


    @Override
    public IBinder onBind(Intent intent)
    {
        return null;
    }

    @SuppressLint("MissingPermission")
    private void DeviceLocation() {
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
            //here is the thread in the requirements
            new Thread(new Runnable() {
            @Override
            public void run()
            {
                 //get the current location to string addess
                 showUILocation(location);
                 //search in DB the curent address
                if(ifInDatabase()) {
                    Log.d("ifindata:", "true");
                    flag=1;
                    //if in DB find the task name
                    findTaskName();
                }

            }
            }).start();
            }

            @Override
            public void onProviderEnabled(String provider)
            {
            }

            @Override
            public void onProviderDisabled(String provider)
            {
            }
        };

        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,
                0,
                50,
                locationListener);
    }



     private void showUILocation(Location loc){
         if(Geocoder.isPresent()) {
             Geocoder gc = new Geocoder(this /*, Locale.FRENCH */);
             try {
                 List<Address> addressList = gc.getFromLocation(loc.getLatitude(), loc.getLongitude(), 1);
                 if (addressList != null && addressList.size() > 0) {
                     Address address = addressList.get(0);
                     //in order to get a rough location by addressList.get
                     curentAddress = address.getAddressLine(0);
                 }
             }
             catch (Exception e) {e.printStackTrace();}
         }
     }
        public boolean ifInDatabase(){
        try{
            String sql = "SELECT location FROM todosTable";
            Cursor cursor = todoDB.rawQuery(sql, null);
            // Get the index for the column name provided
            int loc = cursor.getColumnIndex("location");
            if (cursor != null && cursor.moveToFirst()) {
            do {
                // Get the results and store them in a String
                String dataLoc = cursor.getString(loc);
                if(curentAddress.equals(dataLoc)){
                    return true;
                }
                // Keep getting results as long as they exist
            } while (cursor.moveToNext());
            }
        } catch (Exception e) {
        }
       return false;
      }

    public void findTaskName(){
        try{
            String sql = "SELECT task FROM todosTable WHERE location='"+curentAddress+"'";
            Cursor cursor = todoDB.rawQuery(sql, null);
            // Get the index for the column task provided
            int task = cursor.getColumnIndex("task");
            if (cursor != null && cursor.moveToFirst()) {
                do {
                    countMyTask++;
                    // Get the results and store them in a String
                    String findTask = cursor.getString(task);
                    myTask=findTask;
                } while (cursor.moveToNext());
             createFGNotification();
            }
        } catch (Exception e) {
        }
    }

    public void openDB() {
        try {
            todoDB = openOrCreateDatabase("todoDB", MODE_PRIVATE, null);
            // build an SQL statement to create 'contacts' table (if not exists)
            String sql = "CREATE TABLE IF NOT EXISTS todosTable (id integer primary key, task VARCHAR,detail VARCHAR,location VARCHAR);";
            todoDB.execSQL(sql);
        }
        catch (Exception e) {
            Log.d("debug", "Error Creating Database");
        }
    }

    private void createFGNotification() {
        //if a task was found
        if(flag==1){
            //if 1 task was found
            if(countMyTask==1) {
                Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                        .setContentTitle("You have a task:  "+myTask+" , waiting to be done in this area!")
                        .setContentText("Task area: " + curentAddress)
                        .setSmallIcon(R.drawable.logo)
                        .setPriority(NotificationCompat.PRIORITY_HIGH)
                        .setContentIntent(pendingIntent)
                        .build();
                startForeground(FG_NOTIFICATION_ID, notification);
                countMyTask=0;
                flag = 0;
                return;
            }
            //if more than 1 task was found
            else{
                Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                        .setContentTitle("You have "+countMyTask+" tasks waiting to be done in this area!")
                        .setContentText("Tasks area: " + curentAddress)
                        .setSmallIcon(R.drawable.logo)
                        .setPriority(NotificationCompat.PRIORITY_HIGH)
                        .setContentIntent(pendingIntent)
                        .build();
                startForeground(FG_NOTIFICATION_ID, notification);
                countMyTask=0;
                flag = 0;
                return;
            }
        }
        //fourgrand notification to say that the service work
        else {
            // create Notification
            Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
               .setContentTitle("TaskLocation keeps track of your location...")
                .setContentText("Tap to stop following you!")
                 .setSmallIcon(R.drawable.logo)
                 .setPriority(NotificationCompat.PRIORITY_HIGH)
                 .setContentIntent(pendingIntent)
                  .build();
            startForeground(FG_NOTIFICATION_ID, notification);
        }
    }
}














