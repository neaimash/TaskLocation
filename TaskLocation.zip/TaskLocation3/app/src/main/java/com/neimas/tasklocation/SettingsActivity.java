package com.neimas.tasklocation;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ActivityManager;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class SettingsActivity extends AppCompatActivity {
    private SQLiteDatabase todoDB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        setContentView(R.layout.activity_settings);
       //check if service run now and highlight the  relevant button
        checkIfMyFGServiceRunning();
        openDB();
        //click on "start folowing" the service begin
        Button btn1 = findViewById(R.id.btn_start_ID);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick (View v){
                startService();
            }
        });
        //click on "stop folowing" the service stop
        Button btn2= findViewById(R.id.btn_stop_ID);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick (View v){
                stopService();
            }
        });
        //click on "reset" the date reset by delete sqlite
        Button btn3= findViewById(R.id.reset_id);
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick (View v){
             resetDB();
            }
        });
    }

    @SuppressWarnings("deprecation")
    private void checkIfMyFGServiceRunning() {
        boolean isRunning = false;
        ActivityManager manager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (MyService.class.getName().equals(service.service.getClassName())) {
                isRunning = true;
                break;
            }
        }
        if (isRunning) {
            findViewById(R.id.btn_start_ID).setEnabled(false);
            findViewById(R.id.btn_stop_ID).setEnabled(true);
        } else {
            findViewById(R.id.btn_start_ID).setEnabled(true);
            findViewById(R.id.btn_stop_ID).setEnabled(false);
        }
    }

    public void resetDB(){
        new Thread(new Runnable() {
          @Override
          public void run() {
           try {
               String sql="DELETE from todosTable";
               todoDB.execSQL(sql);
               Intent intent=new Intent(SettingsActivity.this, MainActivity.class);
               startActivity(intent);
           } catch (Exception e) {
           }
          }
        }).start();
    }
    public void startService() {
        startForegroundService(new Intent(this, MyService.class));
        findViewById(R.id.btn_start_ID).setEnabled(false);
        findViewById(R.id.btn_stop_ID).setEnabled(true);
    }

    public void stopService() {
        stopService(new Intent(this, MyService.class));
        findViewById(R.id.btn_start_ID).setEnabled(true);
        findViewById(R.id.btn_stop_ID).setEnabled(false);
        Toast.makeText(this, "Following Stoped!", Toast.LENGTH_SHORT).show();
    }

    public void openDB() {
        try {
            todoDB = openOrCreateDatabase("todoDB", MODE_PRIVATE, null);
            // build an SQL statement to create 'contacts' table (if not exists)
            String sql = "CREATE TABLE IF NOT EXISTS todosTable (id integer primary key, todo VARCHAR,details VARCHAR,location VARCHAR);";
            todoDB.execSQL(sql);
        }
        catch (Exception e) {
            Log.d("debug", "Error Creating Database");
        }
    }
}

// new Thread(new Runnable() {
//@Override
//public void run() {
//        try {
//
//        } catch (Exception e) {
//
//        }
//        }
//        }).start();

//    runOnUiThread(new Runnable()
//    {
//        public void run() {

//    }
//    });