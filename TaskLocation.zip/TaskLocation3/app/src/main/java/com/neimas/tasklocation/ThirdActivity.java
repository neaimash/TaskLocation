package com.neimas.tasklocation;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import com.google.android.gms.tasks.Task;

public class ThirdActivity extends AppCompatActivity {
    private GoogleMap gMap;
    private SQLiteDatabase todoDB;
    private SupportMapFragment mapFragment;
    private String str = "";
    private Location currentLocation;
    private FusedLocationProviderClient fusedLocationProviderClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        setContentView(R.layout.activity_third);

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        openDB();
        //give the current location
        fetchLastLocation();
        mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.mapID);
    }

    private void fetchLastLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(ThirdActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]
                    {Manifest.permission.ACCESS_FINE_LOCATION}, 2);
            return;
        }
        Task<Location> task = fusedLocationProviderClient.getLastLocation();
        task.addOnSuccessListener(location -> {
            if (location != null) {
                currentLocation = location;
                initMap();
            }
        });
    }

    private void initMap() {
        mapFragment.getMapAsync(new OnMapReadyCallback() {
            @Override
            public void onMapReady(GoogleMap googleMap) {
                gMap = googleMap;
                if (ActivityCompat.checkSelfPermission(ThirdActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(ThirdActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                    Toast.makeText(ThirdActivity.this, "Please accept permission", Toast.LENGTH_SHORT).show();
                    return;
                }
                gMap.setMyLocationEnabled(true);

                setCurrentLocation(googleMap);

                // Add a marker in Sydney and move the camera
                gMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
                    @Override
                    public void onMapClick(@NonNull LatLng latLng) {
                        googleMap.addMarker(new MarkerOptions().position(latLng).title("?"));
                        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng,14));
                        Location location = new Location("dd");
//                        location.setLatitude(latLng.latitude);
//                        location.setLongitude(latLng.longitude);
                        showUILocation(latLng.latitude,latLng.longitude);
                    }
                });
            }
        });
    }

    private void setCurrentLocation(GoogleMap googleMap) {
        LatLng latLng = new LatLng(currentLocation.getLatitude(),
                currentLocation.getLongitude());
        MarkerOptions markerOptions = new MarkerOptions().position(latLng)
                .title("Here I am!");
        googleMap.animateCamera(CameraUpdateFactory.newLatLng(latLng));
        googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 5));
        googleMap.addMarker(markerOptions);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    private void showUILocation(double lat,double lon) {
        TextView txvAddress = findViewById(R.id.textView);
        if(Geocoder.isPresent()) {
            Geocoder gc = new Geocoder(this /*, Locale.FRENCH */);
            try {
                List<Address> addressList = gc.getFromLocation(lat, lon, 1);
                if (addressList != null && addressList.size() > 0) {
                    Address address = addressList.get(0);
                    //in order to get a rough location by addressList.get
                    str +=address.getAddressLine(0);
                }
                txvAddress.setText(str);
                Toast.makeText(getApplicationContext(), "Location selected ", Toast.LENGTH_SHORT).show();
                thread(str);
            }
            catch (Exception e) {e.printStackTrace();}
        }
    }


    public void thread(String str){
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Intent intent1 = getIntent();
                    String myTask = intent1.getStringExtra("task");
                    Thread.sleep(3000);
                    Intent intent = new Intent(ThirdActivity.this, SecondActivity.class);
                    intent.putExtra("location", str);
                    intent.putExtra("task", myTask);
                    saveData();
                    startActivity(intent);
                } catch (Exception e) {
                  }
            }
        }).start();
    }

    public void openDB() {
        try {
            todoDB = openOrCreateDatabase("todoDB", MODE_PRIVATE, null);
            // build an SQL statement to create 'contacts' table (if not exists)
            String sql = "CREATE TABLE IF NOT EXISTS todosTable (id integer primary key, todo VARCHAR,details VARCHAR,location VARCHAR);";
            todoDB.execSQL(sql);
        }
        catch (Exception e) {
            Log.d("debug", "Error Creating Database");
        }
    }

    private void saveData() {
        String myLoc = str;
        Intent intent = getIntent();
        String myTask = intent.getStringExtra("task");
        int update = intent.getIntExtra("update", 0);
        String myDetail = intent.getStringExtra("detail");
        // using SQLite DB update if the task exiting
        if (update == 1) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        String sql1 = "UPDATE todostable SET detail='" + myDetail + "' , location='" + myLoc + "' WHERE task='" + myTask + "'";
                        try {
                            todoDB.execSQL(sql1);
                        } catch (Exception e) {
                        }
                    } catch (Exception e) {
                    }
                }
            }).start();

        } else {
            // using SQLite DB insert if the task not exiting
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        String sql = "INSERT INTO todosTable (task,detail,location) VALUES ('" + myTask + "','" + myDetail + "','" + myLoc + "');";
                        try {
                            todoDB.execSQL(sql);
                        } catch (Exception e) {
                        }
                    } catch (Exception e) {
                    }
                }
            }).start();
        }
    }
}